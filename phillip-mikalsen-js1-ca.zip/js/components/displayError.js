function displayError(message) {
    return `<div class="error">${message}</div>`
}